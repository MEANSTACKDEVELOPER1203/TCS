var mongoose = require( 'mongoose' );
var uniqueValidator = require('mongoose-unique-validator');

var validateEmail = function(email) {
  var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return re.test(email)
}

var productSchema = new mongoose.Schema({
  Country: String,
  p_name: {
    type:String,
    required:[true, 'Enter the Product Name']
  },
  CreatedOn: Date,
  mob_no:{
    type:Number,
    min:1000000000,
    max:9999999999,    
    required:[true, 'Enter the Mobile No. '],
    unique:[true, 'Mobile No. Already Register'],
  },
  p_cost: {
    type:String,
    required:[true, 'Enter the Product Cost']
  },
  email:{
      type : String,
      index:true, 
      required:[true, 'Please Enter the Email Id'], 
      unique: [true, 'Please Enter the valid Email Id'],
      validate:[validateEmail, 'Please fill a valid email address'],
      match:[/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please fill a valid email address']

   }

});

productSchema.plugin(uniqueValidator);
var Product = mongoose.model('Product', productSchema);
module.exports = Product; 