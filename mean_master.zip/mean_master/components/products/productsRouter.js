const express = require('express');
let router = express.Router();
let mongoose = require('mongoose');
let Products = mongoose.model('Product');
let ObjectID ="";

router.post('/', (req, res, next) =>{
    console.log(req.body);

    Products.create({
        p_name : req.body.p_name,
        p_cost : req.body.p_cost,
        email : req.body.email,
        mob_no : req.body.mob_no        
    }, function(err, product){
        if(err){
            res.json({"Error":""+err.message});
        }else{
            res.json({"message":"product saved succesfully"});
        }
    });

    //res.json({"message":"Welcome to node js product routers"});
});

router.get('/', (req, res, next)=>{
    Products.find(function(err, listOfProduct){
        if(err){
            res.status(404).json({"message":"Error while getting all product list"
            +err.message});
        }else{
            res.json(listOfProduct);
        }
    });
});

router.get('/:email', (req, res, next)=>{
    //res.json({"message":req.params.email})
    //Products.findById(req.params.id, (err, userDetail)=>{

    Products.findOne({"email":req.params.email}, (err, userDetail)=>{
        if(err){
            res.status(404).json({"message":"Error while getting user detail by email  "
            +err.message});
        }
        else{
            res.status(200).json(userDetail);
        }
    });
});

router.put('/:id/:p_name', (req, res, next)=>{
    console.log(req.params.id);
    console.log(req.params.p_name);
    Products.findByIdAndUpdate({_id:ObjectID(req.params.id)}, {$set:{p_name:req.params.p_name}}, (err, result)=>{
        if(err){
            err.status(404).json({"message":"Error while update the data "
        +err.message});
        }else{
            res.json(result);
        }
    });
    //res.status(300).json({"message":"Update succes"});
});
















router.get('/ByChar:char', (req, res, next) => {
    res.json({"message":"Welcome to search  ===="+req.params.char})
    //var searchByChar = req.params.char;
    //console.log("Search by Character========"+req.params.char);    
    // Products.find({"email":{"$regex":".*"+req.params.char+".*"}}, (err, docs)=>{
    //     if(err){
    //         res.status(404).json({"message":"Error while searching data by char "
    //     +err.message});
    //     }else{
    //         res.json({"message":"Success"});
    //     }
    // });
});

router.get('/', (req, res, next) => {
   // var Product
    res.json({"message":"Get Product Detail by schema"});
});

module.exports=router;