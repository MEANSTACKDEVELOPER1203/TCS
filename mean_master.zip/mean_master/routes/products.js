const express = require('express');
let router = express.Router();

router.post('/', (req, res, next) =>{
    console.log(req.body);
    res.json({"message":"Welcome to node js"});
});

module.exports=router;