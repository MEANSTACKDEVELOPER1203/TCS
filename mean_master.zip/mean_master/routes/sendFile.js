var express = require('express');
var fs = require('fs');
var path = require('path');
var router = express.Router();


//var filePath = app.use(express.static(path.join(__dirname, 'file')));
//console.log(filePath);
//console.log(app.use(express.static(path.join(__dirname, 'file'))));
console.log("path of the dir "+__dirname.split('/routes'));
console.log("path of the filename=="+__filename);

router.get('/', (req, res, next) =>{


    res.sendFile(__dirname+"/relNew.tct");
    //res.writeHead(200, {"Content-Type":"text/html"})
    // fs.open(__dirname+"/routes/sample.txt", function(err){
    //     if(err){
    //         res.status(404).json({"message":"Error while open the file"})
    //     }else{
    //         fs.readFile(__dirname+"/sample.txt", function(err2, data){
    //             if(err2){
    //                 res.status(404).json({"message":"Error while reading data in sample.txt"+
    //             err2.message});
    //             }else{
    //                 console.log(data);
    //                 if(data === "A"){
    //                     console.log("dataAAAAAA ==== "+data);
    //                     fs.writeFile(__dirname+"/routes/sample.txt", "B");
    //                     res.sendFile(__dirname+"/relNew.tct");
    //                     fs.close();
    //                 }
    //                 if(data === "B"){
    //                     console.log("data   BBBBB===="+data);
    //                     fs.writeFile(__dirname+"/routes/sample.txt", "A");
    //                     res.sendFile(__dirname+"/rohit.tct");
    //                     fs.close();
    //                 }
    //             }
    //         });
    //     }
    // });
    

    //res.sendFile(__dirname+"/relNew.tct");
    //res.json({"message":"File have sended successfully"});
    
});

router.get('/', (req, res, next) =>{
    //res.writeHead(200, {"Content-Type":"text/html"})
    res.sendFile(__dirname+"/relNew.tct", function(err){
        if(err){
            res.status(404).json({"Error":"Error while sending the file======"
            +err.message});
        }else{
            res.status(200).json({"message":"send file"});
            //res.end();
        }
    });
    
});


module.exports = router;